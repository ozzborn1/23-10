﻿namespace API.Models
{
    public class PagerVM
    {
        public int PagesCount { get; set; }

        public int Page { get; set; }

        public int ItemsPerPage { get; set; }
    }
}