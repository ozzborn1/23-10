﻿namespace API.Models.Filters
{
    public class TeamsFilterVM
    {
        public string ProjectName { get; set; }

        public string TeamName { get; set; }
    }
}