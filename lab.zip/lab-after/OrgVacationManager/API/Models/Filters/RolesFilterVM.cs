﻿namespace API.Models.Filters
{
    public class RolesFilterVM
    {
        public string Name { get; set; }
    }
}