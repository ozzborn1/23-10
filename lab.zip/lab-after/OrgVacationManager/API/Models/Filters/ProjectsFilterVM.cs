﻿namespace API.Models.Filters
{
    public class ProjectsFilterVM
    {
        public string Name { get; set; }

        public string Description { get; set; }
    }
}