﻿namespace API.Models.ViewModels.TimeOffs.SickTimeOff
{
    public class SickTimeOffsDetailsVM : TimeOffsDetailsVM
    {
    }
}