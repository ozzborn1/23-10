﻿namespace API.Models.ViewModels.TimeOffs.SickTimeOff
{
    public class SickTimeOffsVM : TimeOffsVM
    {
        public string FilePath { get; set; }
    }
}