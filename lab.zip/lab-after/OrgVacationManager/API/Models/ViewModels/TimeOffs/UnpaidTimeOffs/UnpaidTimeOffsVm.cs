﻿namespace API.Models.ViewModels.TimeOffs.UnpaidTimeOffs
{
    public class UnpaidTimeOffsVM : TimeOffsVM
    {
    }
}