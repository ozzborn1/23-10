﻿namespace API.Models.ViewModels.TimeOffs.UnpaidTimeOffs
{
    public class UnpaidTimeOffsEditVM : TimeOffsEditVM
    {
    }
}