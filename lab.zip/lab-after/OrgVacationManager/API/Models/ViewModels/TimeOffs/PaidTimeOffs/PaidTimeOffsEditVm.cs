﻿namespace API.Models.ViewModels.TimeOffs.PaidTimeOffs
{
    public class PaidTimeOffsEditVM : TimeOffsEditVM
    {

    }
}