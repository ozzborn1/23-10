﻿namespace API.Models.ViewModels.TimeOffs
{
    public class TimeOffsApproveVM : TimeOffsIndexVM
    {
       
    }
}