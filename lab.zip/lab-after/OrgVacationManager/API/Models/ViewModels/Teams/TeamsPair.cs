﻿using API.Models.ViewModels.Base;

namespace API.Models.ViewModels.Teams
{
    public class TeamsPair : BasePair
    {
        public string Name { get; set; }
    }
}