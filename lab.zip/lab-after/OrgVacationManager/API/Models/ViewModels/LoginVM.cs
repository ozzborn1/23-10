﻿namespace API.Models.ViewModels
{
    public class LoginVM
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}