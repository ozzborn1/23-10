﻿namespace API.Models.ViewModels.Base
{
    public abstract class BaseDetailsVM : BaseVM
    {
    }
}