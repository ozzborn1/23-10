﻿namespace API.Models.ViewModels.Base
{
    public abstract class BaseVM
    {
        public int Id { get; set; }
    }
}