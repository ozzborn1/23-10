﻿namespace API.Models.ViewModels.Base
{
    public abstract class BaseIndexVM
    {
        public PagerVM Pager { get; set; }
    }
}