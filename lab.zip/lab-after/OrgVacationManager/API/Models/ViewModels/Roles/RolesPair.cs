﻿using API.Models.ViewModels.Base;

namespace API.Models.ViewModels.Roles
{
    public class RolesPair : BasePair
    {
        public string Name { get; set; }
    }
}