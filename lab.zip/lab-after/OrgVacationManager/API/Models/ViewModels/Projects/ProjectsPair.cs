﻿using API.Models.ViewModels.Base;

namespace API.Models.ViewModels.Projects
{
    public class ProjectsPair : BasePair
    {
        public string Name { get; set; }
    }
}