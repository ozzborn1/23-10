﻿using API.Models.ViewModels.Base;

namespace API.Models.ViewModels.Users
{
    public class UsersPair : BasePair
    {
        public string Username { get; set; }
    }
}