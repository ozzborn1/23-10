﻿using API.Models.ViewModels.Base;

namespace API.Models.ViewModels.Users
{
    public class UsersEditRoleVM : BaseEditVM
    {
        public string RoleName { get; set; }
    }
}