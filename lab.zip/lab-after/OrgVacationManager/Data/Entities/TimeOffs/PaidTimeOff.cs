﻿namespace Data.Entities.TimeOffs
{
    public class PaidTimeOff : BaseTimeOff
    {
    }
}
