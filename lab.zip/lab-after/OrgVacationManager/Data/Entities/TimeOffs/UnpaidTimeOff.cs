﻿namespace Data.Entities.TimeOffs
{
    public class UnpaidTimeOff : BaseTimeOff
    {
    }
}
